MODDIR=${0%/*}
CONFIG_FILE="$MODDIR/config.prop"
LOG="$MODDIR/zram_module.log"

# 如果配置文件不存在则退出
if [ ! -f "$CONFIG_FILE" ]; then
  echo "config.prop not found! Exiting."
  exit 1
fi

# 加载变量
. "$CONFIG_FILE"

# 检查变量是否定义
if [ -z "$ZRAM_ALGO" ] || [ -z "$ZRAM_SIZE" ]; then
  echo "ZRAM_ALGO or ZRAM_SIZE is not set! Exiting."
  exit 1
fi

: > "$LOG"
echo "=== $(date '+%F %H:%M:%S') boot ===" >> "$LOG"

# 延迟启动（防止系统未完成初始化）
sleep 30

echo "--- lsmod before ---" >> "$LOG"
lsmod | grep -E "zram|zsmalloc" >> "$LOG" 2>&1

# 重置所有现有 zram 设备
for dev in /dev/block/zram*; do
  if [ -e "$dev" ]; then
    echo "Disabling $dev"
    swapoff "$dev" 2>/dev/null
    echo 1 > "/sys/block/$(basename "$dev")/reset"
  fi
done

# 尝试加载原生 zsmalloc + zram（依赖同一构建产物）
# 若失败则回退：复用 Oplus oplus_bsp_hybridswap_zram 提供的 zram0
if [ -f "$MODDIR/zram/zsmalloc.ko" ] && [ -f "$MODDIR/zram/zram.ko" ]; then
  echo "trying to load zsmalloc.ko" >> "$LOG"
  if insmod "$MODDIR/zram/zsmalloc.ko" 2>>"$LOG"; then
    echo "zsmalloc loaded" >> "$LOG"
    sleep 1
    if ! lsmod | grep -qw "^zram"; then
      echo "trying to load zram.ko" >> "$LOG"
      insmod "$MODDIR/zram/zram.ko" 2>>"$LOG"
      echo "zram insmod rc=$?" >> "$LOG"
    fi
  else
    echo "zsmalloc load FAILED, fallback to oplus driver" >> "$LOG"
  fi
else
  echo "zsmalloc.ko/zram.ko not present, use oplus driver" >> "$LOG"
fi

sleep 2
echo "--- lsmod after ---" >> "$LOG"
lsmod | grep -E "zram|zsmalloc" >> "$LOG" 2>&1

# 配置 zram0
if [ -e /dev/block/zram0 ]; then
  sleep 5
  echo '1' > /sys/block/zram0/reset
  echo '0' > /sys/block/zram0/disksize
  echo '8' > /sys/block/zram0/max_comp_streams
  echo "${ZRAM_ALGO}" > /sys/block/zram0/comp_algorithm

  # 注册次级（重压缩）算法，必须在 disksize 之前
  # 两级串联：一级 zstdn 压不动的页交给二级 zstdn_o 再试
  # 二级在部分内核/机型上不存在，注册失败仅记录，不影响一级
  echo "algo=zstdn priority=1" > /sys/block/zram0/recomp_algorithm
  echo "recomp p1(zstdn) rc=$?" >> "$LOG"

  echo "algo=zstdn_o priority=2" > /sys/block/zram0/recomp_algorithm
  echo "recomp p2(zstdn_o) rc=$?" >> "$LOG"

  echo "${ZRAM_SIZE}" > /sys/block/zram0/disksize
  mkswap /dev/block/zram0 > /dev/null 2>&1
  swapon /dev/block/zram0 > /dev/null 2>&1
  echo "zram0 is now active with ${ZRAM_ALGO} and size ${ZRAM_SIZE}"

  echo "--- recomp_algorithm ---" >> "$LOG"
  cat /sys/block/zram0/recomp_algorithm >> "$LOG" 2>&1
  echo "--- comp_algorithm ---" >> "$LOG"
  cat /sys/block/zram0/comp_algorithm >> "$LOG" 2>&1

  # ---- 自动重压缩循环（固定间隔）----
  # 系统 mmd 未启用，手工复刻 AOSP 策略。
  # 曾尝试闭环 EWMA 自适应间隔，实测 huge 序列是「噪声主导横盘 + 偶发阶跃」，
  # 相邻差分算出的速率被噪声带偏，RATE 单向衰减到下限，反而比固定间隔更差：
  #   固定 1800s  检查 48 次/天  平均水位 126 MiB（实测最优）
  #   固定 300s   检查 288 次    平均水位 134 MiB
  #   自适应      检查 161 次    平均水位 146 MiB
  # 故回归固定间隔；仅保留「压完快速复检」，避免残留仍高时白等半小时。
  (
  RLOG="$MODDIR/recompress.log"
  ST="$MODDIR/status"
  : > "$RLOG"

  THRESH=40000
  IDLE=1800        # 常规检查间隔 30 分钟
  RECHECK=300      # 刚压完，5 分钟后快速复检

  while true; do
    huge=$(awk '{print $8}' /sys/block/zram0/mm_stat)
    ts=$(date '+%F %H:%M:%S')

    if [ "$huge" -gt "$THRESH" ]; then
      echo "=== $ts ===" >> "$RLOG"
      echo "BEFORE: $(cat /sys/block/zram0/mm_stat)" >> "$RLOG"
      echo "type=huge" > /sys/block/zram0/recompress
      echo "AFTER : $(cat /sys/block/zram0/mm_stat)" >> "$RLOG"
      sleep_next=$RECHECK
    else
      echo "$ts huge=$huge skip(<$THRESH)" >> "$RLOG"
      sleep_next=$IDLE
    fi

    echo "$ts huge=$huge next=${sleep_next}s" > "$ST"
    tail -n 300 "$RLOG" > "$RLOG.tmp" && mv "$RLOG.tmp" "$RLOG"
    sleep "$sleep_next"
  done
  ) &
else
  echo "zram0 not found, failed to initialize swap"
  exit 1
fi
